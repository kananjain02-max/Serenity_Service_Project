﻿using System;
using System.Collections.Generic;

namespace Registration_user.Models;

public partial class Provider
{
    public int ProviderId { get; set; }

    public string? Name { get; set; }

    public string? Email { get; set; }

    public string? Contact { get; set; }

    public string? Address { get; set; }

    public int? CategoryId { get; set; }

    public string? Availability { get; set; }

    public double? Rate { get; set; }

    public double? Rating { get; set; }

    public string? ProfilePicture { get; set; }

    public string? Documents { get; set; }

    public string? Status { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual ServiceCategory? Category { get; set; }

    public virtual ICollection<Service> Services { get; set; } = new List<Service>();
}
