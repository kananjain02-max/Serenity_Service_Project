﻿using System;
using System.Collections.Generic;

namespace Registration_user.Models;

public partial class Service
{
    public int ServiceId { get; set; }

    public int? CategoryId { get; set; }

    public int? ProviderId { get; set; }

    public string? ServiceName { get; set; }

    public string? Description { get; set; }

    public double? Price { get; set; }

    public string? Duration { get; set; }

    public string? Status { get; set; }

    public virtual Provider? Provider { get; set; }
}
