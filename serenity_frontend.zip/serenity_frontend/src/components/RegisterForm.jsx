import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import api from "../services/Api";


const RegisterForm = () => {
  const initialValues = { name: "", email: "", password: "",contact:"" };

  const validationSchema = Yup.object({
    name: Yup.string().required("Full name is required"),
    email: Yup.string().email("Invalid email format").required("Email is required"),
    password: Yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
    contact: Yup.string().length(10,"Number should be of 10 digits").required("Contact is required"),
    address: Yup.string().required("Address is required"),
    confirmpassword: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required('Confirm Password is required'),
  });

  const handleSubmit = async (values, { resetForm }) => {
    try {
      await api.post("/auth/register", values);
      alert("Registration successful!");
      resetForm();
    } catch (error) {
      alert("Error: " + error.response?.data || "Something went wrong");
    }
  };

  return (
    <div className="register-form">
      <h2>Create Account</h2>
      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
        <Form>
          <div>
            <label>Full Name</label>
            <Field name="name" type="text" className="form-control"
                  placeholder="Enter your full name" />
            <ErrorMessage name="name" component="div" className="error" />
          </div>
          <div>
            <label>Email</label>
            <Field name="email" type="email" className="form-control"
                  placeholder="Enter your email address"/>
            <ErrorMessage name="email" component="div" className="error" />
          </div>

          <div>
            <label>Contact</label>
            <Field name="contact" type="text" className="form-control"
                  placeholder="Enter your contact number"/>
            <ErrorMessage name="contact" component="div" className="error" />
          </div>

           <div>
            <label>Address</label>
            <Field name="address" type="text" className="form-control"
                  placeholder="Enter your address"/>
            <ErrorMessage name="address" component="div" className="error" />
          </div>

          <div>
            <label>Password</label>
            <Field name="password" type="password" className="form-control"
                  placeholder="Enter your password"/>
            <ErrorMessage name="password" component="div" className="error" />
          </div>

        <div>
            <label>Confirm Password</label>
            <Field name="confirmpassword" type="password" className="form-control"
                  placeholder="Enter password to confirm password"/>
            <ErrorMessage name="confirmpassword" component="div" className="error" />
          </div>

          <button type="submit">Register</button>
        </Form>
      </Formik>
    </div>
  );
};

export default RegisterForm;
