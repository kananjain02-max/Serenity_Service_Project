import axios from "axios";

const api = axios.create({
  baseURL: "", // your .NET Core backend URL
});

export default api;
